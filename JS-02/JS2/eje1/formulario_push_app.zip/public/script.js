
const frutas = [];
const amigos = ["Lucas", "Sofía", "Valentina"];
const numeros = [5, 10, 15];

function agregarFruta() {
  const fruta = document.getElementById("fruta").value.trim();
  if (fruta) {
    frutas.push(fruta);
    document.getElementById("fruta").value = "";
  }
}

function agregarAmigo() {
  const amigo = document.getElementById("amigo").value.trim();
  if (amigo) {
    amigos.push(amigo);
    document.getElementById("amigo").value = "";
  }
}

function agregarNumero() {
  const numero = parseInt(document.getElementById("numero").value.trim(), 10);
  if (!isNaN(numero) && numero > numeros[numeros.length - 1]) {
    numeros.push(numero);
    document.getElementById("numero").value = "";
  }
}

document.getElementById("formulario").addEventListener("submit", function(e) {
  e.preventDefault();
  fetch("/guardar", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ frutas, amigos, numeros })
  })
    .then(res => res.json())
    .then(data => {
      document.getElementById("respuesta").textContent = data.mensaje;
    });
});
